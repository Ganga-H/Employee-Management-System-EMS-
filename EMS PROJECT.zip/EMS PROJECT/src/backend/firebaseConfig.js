import { initializeApp } from "firebase/app";

//! Authentication services provided by the firebase
import { getAuth } from "firebase/auth";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCyRHIdR6ZWWinXz11v04jeGwKqblhJauE",
  authDomain: "ems-project-df2cf.firebaseapp.com",
  projectId: "ems-project-df2cf",
  storageBucket: "ems-project-df2cf.firebasestorage.app",
  messagingSenderId: "212849729306",
  appId: "1:212849729306:web:b679ab51b3afd6bd3f96a3",
};

// Initialize Firebase
const firebaseApp = initializeApp(firebaseConfig);

export let __AUTH = getAuth(firebaseApp);
